<?php
/*
 *---------------------------------------------------------------
 * APPLICATION ENVIRONMENT
 *---------------------------------------------------------------
 * 'development', 'testing', 'production'
 */
//define('ENVIRONMENT', isset($_SERVER['CI_ENV']) ? $_SERVER['CI_ENV'] : 'development');
define('ENVIRONMENT', isset($_SERVER['CI_ENV']) ? $_SERVER['CI_ENV'] : 'production');

if (defined('ENVIRONMENT')) {
    switch (ENVIRONMENT) {
        case 'development':
            error_reporting(-1);
            ini_set('display_errors', 1);
        break;
        case 'testing':
        case 'production':
            ini_set('display_errors', 0);
            error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT & ~E_USER_NOTICE & ~E_USER_DEPRECATED);
        break;
        default:
            header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
            echo 'The application environment is not set correctly.';
            exit(1);
    }
}

/*
 *---------------------------------------------------------------
 * SYSTEM FOLDER NAME
 *---------------------------------------------------------------
 */
$system_path = 'system';

/*
 *---------------------------------------------------------------
 * APPLICATION FOLDER NAME
 *---------------------------------------------------------------
 */
$application_folder = 'application';

/*
 *---------------------------------------------------------------
 * VIEW FOLDER NAME
 *---------------------------------------------------------------
 */
$view_folder = '';


/* ---------------------------------------------------------------
 * CUSTOM CONTROLLERS DIRECTORY
 * --------------------------------------------------------------- */
$routing['directory'] = '';
$routing['controller'] = '';
$routing['function'] = '';


/*
 * ---------------------------------------------------------------
 *  LOAD THE BOOTSTRAP FILE
 * ---------------------------------------------------------------
 */

// The path to the "system" folder
if (($_temp = realpath($system_path)) !== FALSE) {
    $system_path = $_temp.DIRECTORY_SEPARATOR;
} else {
    $system_path = rtrim($system_path, '/\\').DIRECTORY_SEPARATOR;
}

// Is the system path correct?
if (!is_dir($system_path)) {
    header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
    echo 'Your system folder path does not appear to be set correctly. Please open the following file and correct this: '.pathinfo(__FILE__, PATHINFO_BASENAME);
    exit(3);
}

// The path to the "application" folder
if (is_dir($application_folder)) {
    if (($_temp = realpath($application_folder)) !== FALSE) {
        $application_folder = $_temp.DIRECTORY_SEPARATOR;
    } else {
        $application_folder = rtrim($application_folder, '/\\').DIRECTORY_SEPARATOR;
    }
}

// The path to the "views" folder
if (!is_dir($view_folder)) {
    if (!empty($view_folder)) {
        header('HTTP/1.1 503 Service Unavailable.', TRUE, 503);
        echo 'Your view folder path does not appear to be set correctly.';
        exit(3);
    }
}

// Define the CodeIgniter constants
define('SELF',        pathinfo(__FILE__, PATHINFO_BASENAME));
define('BASEPATH',    $system_path);
define('FCPATH',      dirname(__FILE__).DIRECTORY_SEPARATOR);
define('SYSPATH',     $system_path);
define('APPPATH',     $application_folder);
define('VIEWPATH',    $view_folder != '' ? rtrim($view_folder, '/\\').DIRECTORY_SEPARATOR : APPPATH.'views'.DIRECTORY_SEPARATOR);

// Load the framework bootstrap file
require_once BASEPATH.'core/CodeIgniter.php';
